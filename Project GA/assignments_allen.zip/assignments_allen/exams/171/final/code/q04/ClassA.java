public class ClassA { 
    protected int x;

    public ClassA( int xin ) {
        x = xin; 
    }

    public int getValue() { 
        return x;
    } 
}