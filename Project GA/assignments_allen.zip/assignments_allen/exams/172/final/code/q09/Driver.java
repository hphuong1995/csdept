public class Driver
{
    public static void main( String[] args )
    {
        BetterWindow window = new BetterWindow( "test" );
    }
    
}
