
public class StringWorker
{
    private String s;
    
    public StringWorker( String str )
    {
        str = s;
    }
    
    public void printCaps()
    {
        String output = s.toUpperCase();
        System.out.println( output );
    }
}
