'use strict';

var utils = require('../utils/writer.js');
var Default = require('../service/DefaultService');

module.exports.instCreateCour = function instCreateCour (req, res, next) {
  var course = req.swagger.params['course'].value;
  Default.instCreateCour(course)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.instCreateNewQues = function instCreateNewQues (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  var question = req.swagger.params['question'].value;
  Default.instCreateNewQues(cid,question)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.instDelQuesById = function instDelQuesById (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  var qid = req.swagger.params['qid'].value;
  Default.instDelQuesById(cid,qid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.instGetAllAnsw = function instGetAllAnsw (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  var qid = req.swagger.params['qid'].value;
  Default.instGetAllAnsw(cid,qid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.instGetAllCour = function instGetAllCour (req, res, next) {
  Default.instGetAllCour()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.instGetAllQues = function instGetAllQues (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  Default.instGetAllQues(cid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.instGetOneAnsw = function instGetOneAnsw (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  var qid = req.swagger.params['qid'].value;
  var aid = req.swagger.params['aid'].value;
  Default.instGetOneAnsw(cid,qid,aid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.instGetOneCour = function instGetOneCour (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  Default.instGetOneCour(cid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.instGetOneQues = function instGetOneQues (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  var qid = req.swagger.params['qid'].value;
  Default.instGetOneQues(cid,qid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.instructorCoursesCidDELETE = function instructorCoursesCidDELETE (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  Default.instructorCoursesCidDELETE(cid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.register = function register (req, res, next) {
  var account = req.swagger.params['account'].value;
  Default.register(account)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.stuCreateNewAnsw = function stuCreateNewAnsw (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  var qid = req.swagger.params['qid'].value;
  var answer = req.swagger.params['answer'].value;
  Default.stuCreateNewAnsw(cid,qid,answer)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.stuGetAllCour = function stuGetAllCour (req, res, next) {
  Default.stuGetAllCour()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.stuGetAllQues = function stuGetAllQues (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  Default.stuGetAllQues(cid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.stuGetOneCour = function stuGetOneCour (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  Default.stuGetOneCour(cid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.stuGetOneQues = function stuGetOneQues (req, res, next) {
  var cid = req.swagger.params['cid'].value;
  var qid = req.swagger.params['qid'].value;
  Default.stuGetOneQues(cid,qid)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.userLogin = function userLogin (req, res, next) {
  var user = req.swagger.params['user'].value;
  Default.userLogin(user)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.userLogout = function userLogout (req, res, next) {
  Default.userLogout()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
