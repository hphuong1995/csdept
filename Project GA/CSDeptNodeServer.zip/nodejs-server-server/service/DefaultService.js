'use strict';


/**
 * Instructor create a course
 * Instructor create a course
 *
 * course Course  (optional)
 * returns Course
 **/
exports.instCreateCour = function(course) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "uid" : "uid",
  "cname" : "cname",
  "cid" : "cid"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Instructor create a new question of a course
 * Instructor create a new question of a course
 *
 * cid String course id
 * question Question  (optional)
 * returns Question
 **/
exports.instCreateNewQues = function(cid,question) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "type" : "code",
  "qid" : "qid",
  "content" : "content",
  "tid" : "tid"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Instructor delete a question by Id
 * Instructor delete a question by Id
 *
 * cid String course id
 * qid String Question Id
 * no response value expected for this operation
 **/
exports.instDelQuesById = function(cid,qid) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Instructor get all answer for a question
 * Instructor get all answer for a question
 *
 * cid String course id
 * qid String Question Id
 * returns List
 **/
exports.instGetAllAnsw = function(cid,qid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "uid" : "uid",
  "aid" : "aid",
  "qid" : "qid",
  "content" : "content"
}, {
  "uid" : "uid",
  "aid" : "aid",
  "qid" : "qid",
  "content" : "content"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Instructor get all courses
 * Instructor get all courses
 *
 * returns List
 **/
exports.instGetAllCour = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "uid" : "uid",
  "cname" : "cname",
  "cid" : "cid"
}, {
  "uid" : "uid",
  "cname" : "cname",
  "cid" : "cid"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Instructor get all questions of a course
 * Instructor get all questions of a course
 *
 * cid String course id
 * returns List
 **/
exports.instGetAllQues = function(cid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "type" : "code",
  "qid" : "qid",
  "content" : "content",
  "tid" : "tid"
}, {
  "type" : "code",
  "qid" : "qid",
  "content" : "content",
  "tid" : "tid"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Instructor get answer for a question
 * Instructor get answer for a question
 *
 * cid String course id
 * qid String Question Id
 * aid String Answer Id
 * returns Answer
 **/
exports.instGetOneAnsw = function(cid,qid,aid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "uid" : "uid",
  "aid" : "aid",
  "qid" : "qid",
  "content" : "content"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Instructor get a course
 * Instructor get a course
 *
 * cid String course id
 * returns Course
 **/
exports.instGetOneCour = function(cid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "uid" : "uid",
  "cname" : "cname",
  "cid" : "cid"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Instructor get a Question
 * Instructor get a Question
 *
 * cid String course id
 * qid String Question Id
 * returns Question
 **/
exports.instGetOneQues = function(cid,qid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "type" : "code",
  "qid" : "qid",
  "content" : "content",
  "tid" : "tid"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Instructor delete a course
 * Instructor delete a course
 *
 * cid String course id
 * no response value expected for this operation
 **/
exports.instructorCoursesCidDELETE = function(cid) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * New user register for new account
 *
 * account User new account info (optional)
 * no response value expected for this operation
 **/
exports.register = function(account) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Create new answer for a question
 * Create new answer for a question
 *
 * cid String course id
 * qid String Question Id
 * answer Answer  (optional)
 * returns Answer
 **/
exports.stuCreateNewAnsw = function(cid,qid,answer) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "uid" : "uid",
  "aid" : "aid",
  "qid" : "qid",
  "content" : "content"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Student get all courses
 * Student get all courses
 *
 * returns List
 **/
exports.stuGetAllCour = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "uid" : "uid",
  "cname" : "cname",
  "cid" : "cid"
}, {
  "uid" : "uid",
  "cname" : "cname",
  "cid" : "cid"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Student get all questions of a course
 * Student get all questions of a course
 *
 * cid String course id
 * returns List
 **/
exports.stuGetAllQues = function(cid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "type" : "code",
  "qid" : "qid",
  "content" : "content",
  "tid" : "tid"
}, {
  "type" : "code",
  "qid" : "qid",
  "content" : "content",
  "tid" : "tid"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Student get a course
 * Student get a course
 *
 * cid String course id
 * returns Course
 **/
exports.stuGetOneCour = function(cid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "uid" : "uid",
  "cname" : "cname",
  "cid" : "cid"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Student get a Question
 * Student get a Question
 *
 * cid String course id
 * qid String Question Id
 * returns Question
 **/
exports.stuGetOneQues = function(cid,qid) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "type" : "code",
  "qid" : "qid",
  "content" : "content",
  "tid" : "tid"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * User log in
 *
 * user User user to log in (optional)
 * no response value expected for this operation
 **/
exports.userLogin = function(user) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * User log out
 * User Log out
 *
 * no response value expected for this operation
 **/
exports.userLogout = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

